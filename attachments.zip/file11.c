#include <stdio.h>
int main() {
    int a=5, b=3;
    printf("Sum = %d\n", a+b);
    return 0;
}
