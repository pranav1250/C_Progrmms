#include <stdio.h>
#include <math.h>
int main() {
    double x=2, y=5;
    printf("%.2f^%.2f = %.2f\n", x, y, pow(x,y));
    return 0;
}
