#include <stdio.h>
int main() {
    int a=7;
    printf("Area of square = %d\n", a*a);
    return 0;
}
