#include <stdio.h>
int main() {
    float b=10, h=5;
    printf("Area of triangle = %.2f\n", 0.5*b*h);
    return 0;
}
