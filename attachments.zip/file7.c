#include <stdio.h>
int main() {
    float pi=3.14;
    printf("Value of pi: %.2f\n", pi);
    return 0;
}
