#include <stdio.h>
#define PI 3.14
int main() {
    float r=5;
    printf("Area of circle = %.2f\n", PI*r*r);
    return 0;
}

