#include <stdio.h>
int main() {
    printf("%-10s %5d\n", "Marks", 95);
    return 0;
}
