#include <stdio.h>
int main() {
    int a=7;
    printf("Perimeter of square = %d\n", 4*a);
    return 0;
}
