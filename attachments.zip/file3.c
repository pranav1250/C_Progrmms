#include <stdio.h>
int main() {
    printf("10 20 30\n");
    return 0;
}
