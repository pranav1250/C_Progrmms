#include <stdio.h>
int main() {
    int n=7;
    if(n%2==0)
        printf("Even\n");
    else
        printf("Odd\n");
    return 0;
}

