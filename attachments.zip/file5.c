#include <stdio.h>
int main() {
    char c='A';
    printf("Character: %c\n", c);
    return 0;
}
