#include <stdio.h>
int main() {
    int a=10, b=20;
    printf("Average = %d\n", (a+b)/2);
    return 0;
}
