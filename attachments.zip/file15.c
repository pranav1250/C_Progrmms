#include <stdio.h>
int main() {
    int a=20, b=3;
    printf("Remainder = %d\n", a%b);
    return 0;
}
