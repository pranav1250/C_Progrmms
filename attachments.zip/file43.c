#include <stdio.h>
int main() {
    int a=5, b=9;
    if(a>b)
        printf("%d is larger\n", a);
    else
        printf("%d is larger\n", b);
    return 0;
}
