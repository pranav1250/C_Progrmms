#include <stdio.h>
int main() {
    printf("C Programming is fun!\n");
    return 0;
}
