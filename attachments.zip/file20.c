#include <stdio.h>
int main() {
    int n=3;
    printf("Cube = %d\n", n*n*n);
    return 0;
}
