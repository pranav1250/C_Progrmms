include <stdio.h>
int main() {
    int l=8, w=4;
    printf("Area of rectangle = %d\n", l*w);
    return 0;
}
