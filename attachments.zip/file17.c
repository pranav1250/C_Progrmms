#include <stdio.h>
int main() {
    int a=4, b=2;
    printf("Result = %d\n", (a+b)*(a-b));
    return 0;
}
