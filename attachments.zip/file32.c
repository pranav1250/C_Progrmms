#include <stdio.h>
int main() {
    float f=98.6;
    printf("Celsius = %.2f\n", (f-32)*5/9);
    return 0;
}
