#include <stdio.h>
int main() {
    int a=10, b=6;
    printf("Difference = %d\n", a-b);
    return 0;
}
