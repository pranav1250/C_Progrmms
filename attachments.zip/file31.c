#include <stdio.h>
int main() {
    float c=37;
    printf("Fahrenheit = %.2f\n", (c*9/5)+32);
    return 0;
}
