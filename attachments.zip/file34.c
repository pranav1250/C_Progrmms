#include <stdio.h>
int main() {
    int a=10, b=20;
    printf("Minimum = %d\n", (a<b)?a:b);
    return 0;
}
