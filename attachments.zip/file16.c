#include <stdio.h>
int main() {
    int a=2, b=3, c=5;
    printf("Sum = %d\n", a+b+c);
    return 0;
}
