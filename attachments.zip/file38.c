#include <stdio.h>
int main() {
    int n=29;
    printf("Remainder = %d\n", n%7);
    return 0;
}
