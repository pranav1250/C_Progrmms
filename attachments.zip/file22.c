#include <stdio.h>
int main() {
    int l=10, w=5;
    printf("Perimeter of rectangle = %d\n", 2*(l+w));
    return 0;
}
