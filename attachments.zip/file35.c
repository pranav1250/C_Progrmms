#include <stdio.h>
int main() {
    int a=5, b=10, c=15;
    printf("Average = %.2f\n", (a+b+c)/3.0);
    return 0;
}
