#include <stdio.h>
#include <math.h>
int main() {
    double n=16;
    printf("Square root = %.2f\n", sqrt(n));
    return 0;
}
