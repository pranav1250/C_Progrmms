#include <stdio.h>
int main() {
    int n=-5;
    if(n>=0)
        printf("Positive\n");
    else
        printf("Negative\n");
    return 0;
}
