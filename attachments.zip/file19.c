#include <stdio.h>
int main() {
    int n=6;
    printf("Square = %d\n", n*n);
    return 0;
}
