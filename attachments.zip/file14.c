#include <stdio.h>
int main() {
    int a=20, b=5;
    printf("Quotient = %d\n", a/b);
    return 0;
}
