#include <stdio.h>
int main() {
    int x=100;
    printf("Integer: %d\n", x);
    return 0;
}
