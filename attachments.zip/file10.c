#include <stdio.h>
int main() {
    char c='Z';
    printf("ASCII of %c = %d\n", c, c);
    return 0;
}
