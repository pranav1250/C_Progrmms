#include <stdio.h>
int main() {
    int a=7, b=4;
    printf("Product = %d\n", a*b);
    return 0;
}
