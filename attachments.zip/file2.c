#include <stdio.h>
int main() {
    printf("My name is John\n");
    return 0;
}
