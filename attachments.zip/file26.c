#include <stdio.h>
int main() {
    float p=1000, r=5, t=2;
    printf("Simple Interest = %.2f\n", (p*r*t)/100);
    return 0;
}
