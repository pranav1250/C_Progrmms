#include <stdio.h>
int main() {
    int n=0;
    if(n==0)
        printf("Number is zero\n");
    else if(n%2==0)
        printf("Number is even\n");
    else
        printf("Number is odd\n");
    return 0;
}
