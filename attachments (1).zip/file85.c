#include <stdio.h>
int main() {
    int attendance=75;
    if(attendance>=75)
        printf("Allowed for exam\n");
    else
        printf("Not allowed for exam\n");
    return 0;
}
