#include <stdio.h>
int main() {
    int n=-7;
    if(n>0)
        printf("Positive\n");
    else if(n<0)
        printf("Negative\n");
    else
        printf("Zero\n");
    return 0;
}
