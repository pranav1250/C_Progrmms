#include <stdio.h>
int main() {
    int n=14;
    n%2==0 ? printf("Even\n") : printf("Odd\n");
    return 0;
}
