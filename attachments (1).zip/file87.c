#include <stdio.h>
int main() {
    int n=99;
    if(n>=10 && n<=99)
        printf("%d is a two-digit number\n", n);
    else
        printf("%d is not a two-digit number\n", n);
    return 0;
}
