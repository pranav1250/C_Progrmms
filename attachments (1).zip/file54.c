#include <stdio.h>
int main() {
    int n=50;
    if(n%10==0)
        printf("%d is multiple of 10\n", n);
    else
        printf("%d is not multiple of 10\n", n);
    return 0;
}
