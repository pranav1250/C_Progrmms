#include <stdio.h>
int main() {
    int n=10;
    for(int i=1;i<=n;i++) printf("%d ", i*i);
    return 0;
}
