#include <stdio.h>
int main() {
    for(char c='A';c<='Z';c++)
        printf("%c ", c);
    return 0;
}
