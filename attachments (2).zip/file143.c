#include <stdio.h>
int main() {
    int a=2, d=3, n=5;
    for(int i=0;i<n;i++) printf("%d ", a+i*d);
    return 0;
}
