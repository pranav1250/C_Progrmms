#include <stdio.h>
int main() {
    for(char c='a';c<='z';c++)
        printf("%c ", c);
    return 0;
}
